from setuptools import setup

setup(
    name="TuModeloDeClientes+Almada",
    version="1.0",
    author="Guido Almada",
    description="Crear_editar_clientes",
    author_email="guido.almada.91@gmail.com",
    packages=["TuModeloDeClientes+Almada"]

)